#ifndef UPDATE_STATE_H
#define UPDATE_STATE_H

void update_state(int *x, int reaction);

#endif 