#ifndef PROP_H_
#define PROP_H_

void prop(int* x, double* w);

#endif

